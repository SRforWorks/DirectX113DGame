#pragma once
#include <DX3D/All.h>
#include <sstream>

class MyGame : public Game
{
public:
	MyGame();
	~MyGame();

protected:
	virtual void onCreate();
	virtual void onUpdate(f32 deltaTime);

private:
	void setUp();

private:
	Entity* m_entity = nullptr;
	Entity* m_player = nullptr;

	// ui
	Entity* m_text = nullptr;

	Entity* m_cross = nullptr;
	Entity* m_health = nullptr;
	Entity* m_ammo = nullptr;

	TerrainComponent* m_terrainComponent = nullptr;

	f32 m_rotation = 0.0f;

	bool m_locked = true;

private:
	bool isSkyboxEnabled = false;
	bool isFogEnabled = false;
};
