#include <DX3D/Prerequisites.h>

#include <time.h>

#include "MyGame.h"
#include "Player.h"

MyGame::MyGame()
{
}

MyGame::~MyGame()
{
}

void MyGame::onCreate()
{
	Game::onCreate();

	srand((ui32)time(nullptr));

	setUp();

	FontUtility fontUtility;
	fontUtility.createFont(L"Bahnschrift", 16, L"Assets\\Fonts\\");



	auto sphere = getResourceManager()->createResourceFromFile<Mesh>(L"Assets/Meshes/sphere.obj");
	auto sky = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/sky.jpg");
	auto heightMap = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/height_map.png");
	auto waveHeightMap = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/waveHeightMap.png");
	auto grass = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/grass.jpg");
	auto ground = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/ground.jpg");
	auto skyMat = getResourceManager()->createResourceFromFile<Material>(L"Assets/Shaders/SkyBox.hlsl");
	auto font = getResourceManager()->createResourceFromFile<Font>(L"Assets/Fonts/Bahnschrift.font");

	auto ammo = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/UI/ammo.png");
	auto cross = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/UI/cross.png");
	auto health = getResourceManager()->createResourceFromFile<Texture>(L"Assets/Textures/UI/health.png");

	skyMat->addTexture(sky);
	skyMat->setCullMode(CullMode::Front);

	// skybox
	if (isSkyboxEnabled) {
		auto entity = getWorld()->createEntity<Entity>();
		auto meshComponent = entity->createComponent<MeshComponent>();
		auto transform = entity->getTransform();
		meshComponent->setMesh(sphere);
		meshComponent->addMaterial(skyMat);

		transform->setScale(Vector3D(5000, 5000, 5000));
	}

	// terrain
	{
		auto entity = getWorld()->createEntity<Entity>();
		m_terrainComponent = entity->createComponent<TerrainComponent>();
		m_terrainComponent->setHeightMap(heightMap);
		m_terrainComponent->setGroundMap(grass);
		m_terrainComponent->setCliffMap(ground);

		auto transform = entity->getTransform();
		transform->setScale(Vector3D(1, 1, 1));
	}

	// sea
	{
		auto entity = getWorld()->createEntity<Entity>();
		auto waterComponent = entity->createComponent<WaterComponent>();
		waterComponent->setWaveHeightMap(waveHeightMap);

		auto transform = entity->getTransform();
		transform->setPosition(Vector3D(-768, 15, -768));
	}

	// fog
	if (isFogEnabled) {
		auto entity = getWorld()->createEntity<Entity>();
		auto fogComponent = entity->createComponent<FogComponent>();
		fogComponent->setData(Vector4D(0.75f, 0.75f, 0.3f, 0.5f), 50, 600);
	}

	// light
	{
		m_entity = getWorld()->createEntity<Entity>();
		auto lightComponent = m_entity->createComponent<LightComponent>();
		lightComponent->setColor(Vector4D(0.8f, 0.4f, 0.4f, 1));
		m_entity->getTransform()->setRotation(Vector3D(-0.707f, 0.707f, 0));
	}

	// text
	{
		m_text = getWorld()->createEntity<Entity>();
		auto text = m_text->createComponent<TextComponent>();
		text->setFont(font);
		text->setText(L"Test 2D Text");
		m_text->getTransform()->setPosition(Vector3D(10.0f, 10.0f, 0));
	}

	// cross
	{
		m_cross = getWorld()->createEntity<Entity>();
		auto image = m_cross->createComponent<ImageComponent>();
		image->setImage(cross);
		image->setSize({0, 0, 50, 50});
		auto client = getDisplay()->getClientSize();
		m_cross->getTransform()->setPosition(Vector3D((f32)client.width / 2.0f, (f32)client.height / 2.0f, 0));
	}

	// health
	{
		m_health = getWorld()->createEntity<Entity>();
		auto image = m_health->createComponent<ImageComponent>();
		image->setImage(health);
		image->setSize({ 0, 0, 50, 50 });
		auto client = getDisplay()->getClientSize();
		m_health->getTransform()->setPosition(Vector3D((f32)client.width - 60.0f, (f32)client.height - 60.0f, 0));
	}

	// ammo
	{
		m_ammo = getWorld()->createEntity<Entity>();
		auto image = m_ammo->createComponent<ImageComponent>();
		image->setImage(ammo);
		image->setSize({ 0, 0, 50, 50 });
		auto client = getDisplay()->getClientSize();
		m_ammo->getTransform()->setPosition(Vector3D(10.0f, (f32)client.height - 60.0f, 0));
	}

	m_player = getWorld()->createEntity<Player>();

	getInputSystem()->lockCursor(m_locked);
}

void MyGame::onUpdate(f32 deltaTime)
{
	Game::onUpdate(deltaTime);
	m_rotation += 1.57f * deltaTime;

	m_entity->getTransform()->setRotation(Vector3D(0.707f, -3.14f, 0));
	auto clientSize = getDisplay()->getClientSize();
	auto textComp	= m_text->getComponent<TextComponent>();
	auto textBounds = textComp->getBounds();


	auto playerPos = m_player->getTransform()->getPosition();
	auto playerRot = m_player->getTransform()->getRotation();
	auto p = 180.0f / 3.14f;

	auto height = m_terrainComponent->getHeightFromWorldPoint(playerPos);

	auto infoText = std::wstringstream();
	infoText << L"DirectX11 3DGame Tutorial\n";
	infoText << L"FPS: " << (int)(1.0f / deltaTime) << L"\n";
	infoText << L"Screen Size: (Width: " << (int)clientSize.width << L", Height: " << (int)clientSize.height << L")\n";
	infoText << L"Player Position: (X: " << playerPos.x << L", Y: " << playerPos.y << L", Z: " << playerPos.z << L")\n";
	infoText << L"Player Rotation: (X: " << playerRot.x << L", Y: " << playerRot.y << L", Z: " << playerRot.z << L")\n";
	infoText << L"Terrain Height: " << height << L"\n";

	textComp->setText(infoText.str().c_str());

	if (getInputSystem()->isKeyUp(Key::Escape))
	{
		m_locked = !m_locked;
		getInputSystem()->lockCursor(m_locked);
	}
}

void MyGame::setUp()
{
	isSkyboxEnabled = false;
	isFogEnabled	= true;
}
